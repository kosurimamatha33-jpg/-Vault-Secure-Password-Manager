// server.js
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const authRoutes = require("./routes/auth");
const vaultRoutes = require("./routes/vault");

const app = express();
const PORT = process.env.PORT || 3001;

if (!process.env.JWT_SECRET) {
  console.error(
    "FATAL: JWT_SECRET is not set in .env. Generate one with:\n" +
      '  node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"\n' +
      "and put it in backend/.env as JWT_SECRET=<value>"
  );
  process.exit(1);
}

// --- Security middleware ---
app.use(helmet());
app.use(
  cors({
    origin: process.env.FRONTEND_ORIGIN || "http://localhost:5500",
    credentials: true,
  })
);
app.use(express.json({ limit: "100kb" }));

// Rate limit auth endpoints harder to slow down brute-force attempts.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { error: "Too many attempts. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

// General rate limit for everything else.
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});

app.use("/api/auth", authLimiter, authRoutes);
app.use("/api/vault", generalLimiter, vaultRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// Centralized error handler (catches anything unexpected)
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Password manager backend running on http://localhost:${PORT}`);
});
