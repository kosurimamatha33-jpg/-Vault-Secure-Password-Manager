// routes/vault.js
// CRUD endpoints for vault entries. The server only ever sees ciphertext
// blobs and IVs that were already encrypted in the browser - it has no
// ability to decrypt them and never receives the encryption key.

const express = require("express");
const db = require("../db/database");
const { authenticateToken } = require("../middleware/auth");

const router = express.Router();

router.use(authenticateToken);

// GET all entries for the logged-in user
router.get("/", (req, res) => {
  try {
    const entries = db
      .prepare(
        `SELECT id, website_cipher, website_iv, username_cipher, username_iv,
                password_cipher, password_iv, created_at, updated_at
         FROM vault_entries WHERE user_id = ? ORDER BY created_at DESC`
      )
      .all(req.userId);

    res.json({ entries });
  } catch (err) {
    console.error("Fetch entries error:", err);
    res.status(500).json({ error: "Failed to fetch vault entries" });
  }
});

// POST a new entry
router.post("/", (req, res) => {
  try {
    const {
      websiteCipher,
      websiteIv,
      usernameCipher,
      usernameIv,
      passwordCipher,
      passwordIv,
    } = req.body;

    if (
      !websiteCipher ||
      !websiteIv ||
      !usernameCipher ||
      !usernameIv ||
      !passwordCipher ||
      !passwordIv
    ) {
      return res.status(400).json({ error: "Missing encrypted fields" });
    }

    const result = db
      .prepare(
        `INSERT INTO vault_entries
          (user_id, website_cipher, website_iv, username_cipher, username_iv, password_cipher, password_iv)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        req.userId,
        websiteCipher,
        websiteIv,
        usernameCipher,
        usernameIv,
        passwordCipher,
        passwordIv
      );

    res.status(201).json({ id: result.lastInsertRowid, message: "Entry saved" });
  } catch (err) {
    console.error("Create entry error:", err);
    res.status(500).json({ error: "Failed to save entry" });
  }
});

// PUT update an existing entry (must belong to the logged-in user)
router.put("/:id", (req, res) => {
  try {
    const { id } = req.params;
    const {
      websiteCipher,
      websiteIv,
      usernameCipher,
      usernameIv,
      passwordCipher,
      passwordIv,
    } = req.body;

    const existing = db
      .prepare("SELECT id FROM vault_entries WHERE id = ? AND user_id = ?")
      .get(id, req.userId);

    if (!existing) {
      return res.status(404).json({ error: "Entry not found" });
    }

    db.prepare(
      `UPDATE vault_entries
       SET website_cipher = ?, website_iv = ?, username_cipher = ?, username_iv = ?,
           password_cipher = ?, password_iv = ?, updated_at = datetime('now')
       WHERE id = ? AND user_id = ?`
    ).run(
      websiteCipher,
      websiteIv,
      usernameCipher,
      usernameIv,
      passwordCipher,
      passwordIv,
      id,
      req.userId
    );

    res.json({ message: "Entry updated" });
  } catch (err) {
    console.error("Update entry error:", err);
    res.status(500).json({ error: "Failed to update entry" });
  }
});

// DELETE an entry (must belong to the logged-in user)
router.delete("/:id", (req, res) => {
  try {
    const { id } = req.params;

    const existing = db
      .prepare("SELECT id FROM vault_entries WHERE id = ? AND user_id = ?")
      .get(id, req.userId);

    if (!existing) {
      return res.status(404).json({ error: "Entry not found" });
    }

    db.prepare("DELETE FROM vault_entries WHERE id = ? AND user_id = ?").run(
      id,
      req.userId
    );

    res.json({ message: "Entry deleted" });
  } catch (err) {
    console.error("Delete entry error:", err);
    res.status(500).json({ error: "Failed to delete entry" });
  }
});

module.exports = router;
