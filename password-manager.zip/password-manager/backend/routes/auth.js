// routes/auth.js
// Handles registration and login.
//
// IMPORTANT SECURITY NOTE:
// The master password is sent over HTTPS to the server ONLY for the purpose
// of verifying login (via bcrypt) - the server hashes it and never stores
// or logs the plaintext. The actual VAULT ENCRYPTION KEY is derived
// independently in the browser from the same master password + a salt,
// and that derived key never leaves the browser. So even though the
// password touches the server once for auth, decrypting the vault data
// itself is something only the browser can do.

const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const db = require("../db/database");

const router = express.Router();
const SALT_ROUNDS = 12;

function isStrongPassword(pw) {
  // Require at least 10 chars, one uppercase, one lowercase, one digit, one symbol.
  const lengthOk = pw.length >= 10;
  const upper = /[A-Z]/.test(pw);
  const lower = /[a-z]/.test(pw);
  const digit = /[0-9]/.test(pw);
  const symbol = /[^A-Za-z0-9]/.test(pw);
  return lengthOk && upper && lower && digit && symbol;
}

router.post("/register", async (req, res) => {
  try {
    const { username, masterPassword } = req.body;

    if (!username || !masterPassword) {
      return res.status(400).json({ error: "Username and master password are required" });
    }

    if (username.length < 3) {
      return res.status(400).json({ error: "Username must be at least 3 characters" });
    }

    if (!isStrongPassword(masterPassword)) {
      return res.status(400).json({
        error:
          "Master password must be at least 10 characters and include uppercase, lowercase, a number, and a symbol",
      });
    }

    const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(username);
    if (existing) {
      return res.status(409).json({ error: "Username already taken" });
    }

    const masterPasswordHash = await bcrypt.hash(masterPassword, SALT_ROUNDS);
    // This salt is returned to the client and used for PBKDF2 key derivation
    // for vault encryption. It is NOT a secret - it just needs to be unique
    // and consistent per-user.
    const kdfSalt = crypto.randomBytes(16).toString("hex");

    const result = db
      .prepare(
        "INSERT INTO users (username, master_password_hash, kdf_salt) VALUES (?, ?, ?)"
      )
      .run(username, masterPasswordHash, kdfSalt);

    const token = jwt.sign(
      { userId: result.lastInsertRowid, username },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.status(201).json({
      message: "Account created successfully",
      token,
      kdfSalt,
      username,
    });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ error: "Server error during registration" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { username, masterPassword } = req.body;

    if (!username || !masterPassword) {
      return res.status(400).json({ error: "Username and master password are required" });
    }

    const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);

    // Use a generic error message for both "user not found" and "wrong password"
    // so attackers can't enumerate valid usernames.
    if (!user) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const match = await bcrypt.compare(masterPassword, user.master_password_hash);
    if (!match) {
      return res.status(401).json({ error: "Invalid username or password" });
    }

    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      message: "Login successful",
      token,
      kdfSalt: user.kdf_salt,
      username: user.username,
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Server error during login" });
  }
});

module.exports = router;
