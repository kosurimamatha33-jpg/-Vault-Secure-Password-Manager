// db/database.js
// Initializes the SQLite database and defines the schema.
// Note: passwords are NEVER stored in plaintext here. The "vault_entries"
// table only stores ciphertext + the IV/salt needed to decrypt it client-side.
// The server has no way to read your actual saved passwords.

const Database = require("better-sqlite3");
const path = require("path");

const dbPath = path.join(__dirname, "vault.db");
const db = new Database(dbPath);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Users table: stores the bcrypt hash of the master password (for login auth only)
// plus the PBKDF2 salt the client needs to re-derive the same encryption key.
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    master_password_hash TEXT NOT NULL,
    kdf_salt TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  )
`);

// Vault entries: website/username are stored encrypted too, since metadata
// about what sites someone uses is itself sensitive. Only ciphertext + iv
// per field are stored.
db.exec(`
  CREATE TABLE IF NOT EXISTS vault_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    website_cipher TEXT NOT NULL,
    website_iv TEXT NOT NULL,
    username_cipher TEXT NOT NULL,
    username_iv TEXT NOT NULL,
    password_cipher TEXT NOT NULL,
    password_iv TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )
`);

module.exports = db;
