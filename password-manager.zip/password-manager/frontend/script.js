// script.js
// Main application logic: auth flow, vault rendering, form handling.

let isRegisterMode = false;
let decryptedEntries = []; // cache of decrypted entries for search/render

// ---------- DOM refs ----------
const authScreen = document.getElementById("authScreen");
const appScreen = document.getElementById("appScreen");
const authForm = document.getElementById("authForm");
const authUsername = document.getElementById("authUsername");
const authPassword = document.getElementById("authPassword");
const authError = document.getElementById("authError");
const authSubmitBtn = document.getElementById("authSubmitBtn");
const authSubtitle = document.getElementById("authSubtitle");
const authSwitchText = document.getElementById("authSwitchText");
const authSwitchBtn = document.getElementById("authSwitchBtn");
const authStrengthRow = document.getElementById("authStrengthRow");
const authStrengthFill = document.getElementById("authStrengthFill");
const authStrengthLabel = document.getElementById("authStrengthLabel");
const lockIcon = document.getElementById("lockIcon");

const userBadge = document.getElementById("userBadge");
const lockBtn = document.getElementById("lockBtn");

const entryForm = document.getElementById("entryForm");
const websiteInput = document.getElementById("website");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");
const editingIdInput = document.getElementById("editingId");
const strengthFill = document.getElementById("strengthFill");
const strengthLabel = document.getElementById("strengthLabel");
const generateBtn = document.getElementById("generateBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const formPanelTitle = document.getElementById("formPanelTitle");
const saveBtn = document.getElementById("saveBtn");

const entryList = document.getElementById("entryList");
const emptyState = document.getElementById("emptyState");
const searchInput = document.getElementById("searchInput");
const toast = document.getElementById("toast");

const STRENGTH_COLORS = ["#e2574c", "#e2574c", "#e0a23e", "#3ecf8e", "#3ecf8e"];

// ---------- Utility ----------
function showToast(message, type = "success") {
  toast.textContent = message;
  toast.className = `toast ${type}`;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2800);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function setupPasswordToggle(toggleBtn, input) {
  toggleBtn.addEventListener("click", () => {
    const isPw = input.type === "password";
    input.type = isPw ? "text" : "password";
  });
}

setupPasswordToggle(document.getElementById("toggleAuthPw"), authPassword);
setupPasswordToggle(document.getElementById("togglePw"), passwordInput);

function updateStrengthUI(password, fillEl, labelEl, rowEl) {
  const { score, label } = scorePasswordStrength(password);
  if (rowEl) rowEl.classList.toggle("hidden", password.length === 0);
  fillEl.style.width = `${(score / 4) * 100}%`;
  fillEl.style.backgroundColor = STRENGTH_COLORS[score];
  labelEl.textContent = password ? label : "";
}

authPassword.addEventListener("input", () => {
  if (isRegisterMode) {
    updateStrengthUI(authPassword.value, authStrengthFill, authStrengthLabel, authStrengthRow);
  }
});

passwordInput.addEventListener("input", () => {
  updateStrengthUI(passwordInput.value, strengthFill, strengthLabel, null);
});

generateBtn.addEventListener("click", () => {
  const generated = generateStrongPassword(16);
  passwordInput.value = generated;
  passwordInput.type = "text";
  updateStrengthUI(generated, strengthFill, strengthLabel, null);
});

// ---------- Auth mode switching ----------
authSwitchBtn.addEventListener("click", () => {
  isRegisterMode = !isRegisterMode;
  authError.classList.add("hidden");
  authForm.reset();
  authStrengthRow.classList.add("hidden");

  if (isRegisterMode) {
    authSubtitle.textContent = "Create a new vault";
    authSubmitBtn.textContent = "Create vault";
    authSwitchText.textContent = "Already have a vault?";
    authSwitchBtn.textContent = "Log in";
  } else {
    authSubtitle.textContent = "Unlock with your master password";
    authSubmitBtn.textContent = "Unlock vault";
    authSwitchText.textContent = "Don't have a vault yet?";
    authSwitchBtn.textContent = "Create one";
  }
});

// ---------- Auth submit ----------
authForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  authError.classList.add("hidden");
  authSubmitBtn.disabled = true;
  authSubmitBtn.textContent = isRegisterMode ? "Creating vault..." : "Unlocking...";

  const username = authUsername.value.trim();
  const masterPassword = authPassword.value;

  try {
    const result = isRegisterMode
      ? await api.register(username, masterPassword)
      : await api.login(username, masterPassword);

    setToken(result.token);
    sessionStorage.setItem("username", result.username);

    // Derive the AES key locally from the master password + salt.
    // The master password itself is discarded from memory after this.
    await deriveVaultKey(masterPassword, result.kdfSalt);

    lockIcon.classList.add("unlocked");
    setTimeout(() => enterApp(result.username), 250);
  } catch (err) {
    authError.textContent = err.message;
    authError.classList.remove("hidden");
    authSubmitBtn.disabled = false;
    authSubmitBtn.textContent = isRegisterMode ? "Create vault" : "Unlock vault";
  }
});

// ---------- Enter / lock app ----------
async function enterApp(username) {
  authScreen.classList.add("hidden");
  appScreen.classList.remove("hidden");
  userBadge.textContent = username;
  authForm.reset();
  authPassword.value = "";

  await loadEntries();
}

function lockVault() {
  clearVaultKey();
  clearToken();
  sessionStorage.removeItem("username");
  decryptedEntries = [];
  entryForm.reset();
  editingIdInput.value = "";

  appScreen.classList.add("hidden");
  authScreen.classList.remove("hidden");
  lockIcon.classList.remove("unlocked");
  authPassword.value = "";
  authUsername.value = "";
  authUsername.focus();
}

lockBtn.addEventListener("click", lockVault);

// ---------- Vault entries ----------
async function loadEntries() {
  try {
    const { entries } = await api.getEntries();
    decryptedEntries = await Promise.all(entries.map(decryptEntry));
    renderEntries(decryptedEntries);
  } catch (err) {
    showToast("Failed to load vault: " + err.message, "error");
    if (err.message.includes("Not authenticated") || err.message.includes("Invalid or expired")) {
      lockVault();
    }
  }
}

function renderEntries(list) {
  entryList.innerHTML = "";

  if (list.length === 0) {
    entryList.appendChild(emptyState);
    emptyState.classList.remove("hidden");
    return;
  }

  list.forEach((entry) => {
    const card = document.createElement("div");
    card.className = "entryCard";
    card.innerHTML = `
      <div class="entryMain">
        <div class="entryWebsite">
          ${escapeHtml(entry.website)}
          <span class="encBadge">AES-256-GCM</span>
        </div>
        <div class="entryUsername">${escapeHtml(entry.username)}</div>
        <div class="entryPasswordRow">
          <span class="entryPasswordMask" data-revealed="false" data-plain="${escapeHtml(entry.password)}">••••••••••••</span>
          <button class="iconBtn revealBtn" type="button">Show</button>
          <button class="iconBtn copyBtn" type="button">Copy</button>
        </div>
      </div>
      <div class="entryActions">
        <button class="iconBtn editBtn" type="button">Edit</button>
        <button class="iconBtn danger deleteBtn" type="button">Delete</button>
      </div>
    `;

    const maskEl = card.querySelector(".entryPasswordMask");
    const revealBtn = card.querySelector(".revealBtn");
    revealBtn.addEventListener("click", () => {
      const revealed = maskEl.dataset.revealed === "true";
      maskEl.textContent = revealed ? "••••••••••••" : entry.password;
      maskEl.dataset.revealed = String(!revealed);
      revealBtn.textContent = revealed ? "Show" : "Hide";
    });

    card.querySelector(".copyBtn").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(entry.password);
        showToast("Password copied to clipboard");
      } catch {
        showToast("Couldn't copy - copy manually", "error");
      }
    });

    card.querySelector(".editBtn").addEventListener("click", () => {
      startEdit(entry);
    });

    card.querySelector(".deleteBtn").addEventListener("click", async () => {
      if (!confirm(`Delete the saved entry for "${entry.website}"?`)) return;
      try {
        await api.deleteEntry(entry.id);
        decryptedEntries = decryptedEntries.filter((e) => e.id !== entry.id);
        renderEntries(filterEntries(searchInput.value));
        showToast("Entry deleted");
      } catch (err) {
        showToast("Failed to delete: " + err.message, "error");
      }
    });

    entryList.appendChild(card);
  });
}

function filterEntries(query) {
  const q = query.trim().toLowerCase();
  if (!q) return decryptedEntries;
  return decryptedEntries.filter(
    (e) => e.website.toLowerCase().includes(q) || e.username.toLowerCase().includes(q)
  );
}

searchInput.addEventListener("input", () => {
  renderEntries(filterEntries(searchInput.value));
});

function startEdit(entry) {
  editingIdInput.value = entry.id;
  websiteInput.value = entry.website;
  usernameInput.value = entry.username;
  passwordInput.value = entry.password;
  updateStrengthUI(entry.password, strengthFill, strengthLabel, null);
  formPanelTitle.textContent = "Edit entry";
  saveBtn.textContent = "Update entry";
  cancelEditBtn.classList.remove("hidden");
  websiteInput.focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function resetForm() {
  entryForm.reset();
  editingIdInput.value = "";
  formPanelTitle.textContent = "Add new entry";
  saveBtn.textContent = "Save entry";
  cancelEditBtn.classList.add("hidden");
  strengthFill.style.width = "0%";
  strengthLabel.textContent = "";
}

cancelEditBtn.addEventListener("click", resetForm);

entryForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const website = websiteInput.value.trim();
  const username = usernameInput.value.trim();
  const password = passwordInput.value;
  const editingId = editingIdInput.value;

  if (!website || !username || !password) {
    showToast("Please fill all fields", "error");
    return;
  }

  saveBtn.disabled = true;
  const originalText = saveBtn.textContent;
  saveBtn.textContent = "Encrypting...";

  try {
    const encrypted = await encryptEntry({ website, username, password });

    if (editingId) {
      await api.updateEntry(editingId, encrypted);
      showToast("Entry updated");
    } else {
      await api.createEntry(encrypted);
      showToast("Entry saved");
    }

    resetForm();
    await loadEntries();
  } catch (err) {
    showToast("Failed to save: " + err.message, "error");
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = originalText;
  }
});

// ---------- Session restore (token exists but key derivation needs master password) ----------
// We intentionally do NOT persist the derived key or master password across
// page reloads. If the page reloads, the vault re-locks and requires the
// master password again - this is a deliberate security tradeoff, not a bug.
window.addEventListener("DOMContentLoaded", () => {
  clearToken();
  clearVaultKey();
});
