// crypto.js
//
// All real cryptography happens here, in the browser, using the native
// Web Crypto API (window.crypto.subtle). The server never sees the
// master password's derived key or any plaintext vault data.
//
// Flow:
//   1. User enters master password.
//   2. We derive a 256-bit AES key from it using PBKDF2 (100,000 iterations,
//      SHA-256) with a per-user salt (returned by the server at signup/login).
//      PBKDF2 deliberately makes brute-forcing slow.
//   3. That key lives ONLY in memory for the session (a module-level
//      variable here). It is never persisted, never sent to the server.
//   4. Every field we save (website, username, password) is encrypted
//      individually with AES-256-GCM, which gives both confidentiality
//      and integrity (tamper detection) via its built-in auth tag.
//   5. Each encryption uses a fresh random 12-byte IV (required for GCM
//      to be secure) which is stored alongside the ciphertext (IVs are
//      not secret, just must never repeat for the same key).

let vaultKey = null; // CryptoKey, held only in memory for the active session

function bufToBase64(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

function base64ToBuf(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Derives a 256-bit AES-GCM key from the master password + salt using PBKDF2.
 * Must be called once after login/register before any encrypt/decrypt calls.
 */
async function deriveVaultKey(masterPassword, kdfSaltHex) {
  const encoder = new TextEncoder();
  const saltBytes = new Uint8Array(
    kdfSaltHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
  );

  const baseKey = await crypto.subtle.importKey(
    "raw",
    encoder.encode(masterPassword),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );

  vaultKey = await crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: saltBytes,
      iterations: 100000,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false, // not extractable - cannot be exported out of the CryptoKey object
    ["encrypt", "decrypt"]
  );
}

/** Clears the in-memory key. Call this on logout/lock. */
function clearVaultKey() {
  vaultKey = null;
}

function hasVaultKey() {
  return vaultKey !== null;
}

/**
 * Encrypts a plaintext string. Returns { cipher, iv } both as base64 strings,
 * ready to send to the server or store.
 */
async function encryptField(plaintext) {
  if (!vaultKey) throw new Error("Vault key not initialized - please log in again");

  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encoder = new TextEncoder();

  const ciphertextBuf = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    vaultKey,
    encoder.encode(plaintext)
  );

  return {
    cipher: bufToBase64(ciphertextBuf),
    iv: bufToBase64(iv),
  };
}

/**
 * Decrypts a { cipher, iv } pair (both base64 strings) back to plaintext.
 * Throws if the auth tag doesn't match (i.e. tampered or wrong key).
 */
async function decryptField(cipherB64, ivB64) {
  if (!vaultKey) throw new Error("Vault key not initialized - please log in again");

  const ciphertextBuf = base64ToBuf(cipherB64);
  const iv = base64ToBuf(ivB64);

  const plainBuf = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    vaultKey,
    ciphertextBuf
  );

  return new TextDecoder().decode(plainBuf);
}

/**
 * Encrypts an entire vault entry's three fields at once.
 */
async function encryptEntry({ website, username, password }) {
  const [w, u, p] = await Promise.all([
    encryptField(website),
    encryptField(username),
    encryptField(password),
  ]);

  return {
    websiteCipher: w.cipher,
    websiteIv: w.iv,
    usernameCipher: u.cipher,
    usernameIv: u.iv,
    passwordCipher: p.cipher,
    passwordIv: p.iv,
  };
}

/**
 * Decrypts a raw entry row from the server back into plaintext fields.
 */
async function decryptEntry(row) {
  const [website, username, password] = await Promise.all([
    decryptField(row.website_cipher, row.website_iv),
    decryptField(row.username_cipher, row.username_iv),
    decryptField(row.password_cipher, row.password_iv),
  ]);

  return {
    id: row.id,
    website,
    username,
    password,
    createdAt: row.created_at,
  };
}

/**
 * Simple password strength scorer (0-4) for UI feedback only.
 * This is heuristic, not cryptographic - just for guiding the user.
 */
function scorePasswordStrength(password) {
  if (!password) return { score: 0, label: "" };

  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  score = Math.min(score, 4);

  const labels = ["Very weak", "Weak", "Fair", "Strong", "Very strong"];
  return { score, label: labels[score] };
}

/** Generates a cryptographically random strong password. */
function generateStrongPassword(length = 16) {
  const charset =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+";
  const randomValues = crypto.getRandomValues(new Uint32Array(length));
  let result = "";
  for (let i = 0; i < length; i++) {
    result += charset[randomValues[i] % charset.length];
  }
  return result;
}
