// api.js
// Thin wrapper around fetch() for talking to the backend.

const API_BASE = "http://localhost:3001/api";

function getToken() {
  return sessionStorage.getItem("authToken");
}

function setToken(token) {
  sessionStorage.setItem("authToken", token);
}

function clearToken() {
  sessionStorage.removeItem("authToken");
}

async function apiRequest(path, { method = "GET", body = null, auth = false } = {}) {
  const headers = { "Content-Type": "application/json" };

  if (auth) {
    const token = getToken();
    if (!token) throw new Error("Not authenticated");
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data;
}

const api = {
  register(username, masterPassword) {
    return apiRequest("/auth/register", {
      method: "POST",
      body: { username, masterPassword },
    });
  },

  login(username, masterPassword) {
    return apiRequest("/auth/login", {
      method: "POST",
      body: { username, masterPassword },
    });
  },

  getEntries() {
    return apiRequest("/vault", { auth: true });
  },

  createEntry(encryptedFields) {
    return apiRequest("/vault", {
      method: "POST",
      body: encryptedFields,
      auth: true,
    });
  },

  updateEntry(id, encryptedFields) {
    return apiRequest(`/vault/${id}`, {
      method: "PUT",
      body: encryptedFields,
      auth: true,
    });
  },

  deleteEntry(id) {
    return apiRequest(`/vault/${id}`, { method: "DELETE", auth: true });
  },
};
